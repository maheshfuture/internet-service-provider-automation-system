<?php

$this->add_widget("isp", "dashboard-side", "Isp", "isp/widgets/isp.vue", 2, false);
